package com.te.springbooot2.exception;

public class ProductException extends RuntimeException  {

	public ProductException(String msg) {
		super(msg);
	}
}
